routers = dict(
    BASE=dict(
        default_application="shebanq",
        root_static=[
            "robots.txt",
            "favicon.ico",
            "apple-touch-icon.png",
            "google9e12b65b9e77c1da.html",
        ],
    )
)
